export class BudgetItem{
    // description: string;
    // amount: number;

    constructor(public description: string, public amount: number){
        this.description = description;
        this.amount = amount;
    }
}